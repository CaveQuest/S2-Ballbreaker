comp_z80_size 0xF64 e f�r C-Programm */
#define word_728C_user 0x71C8
#define Obj5F_MapUnc_7240 0x7248
#define off_3A294 0x3A270
#define MapRUnc_Sonic 0x71460
#define movewZ80CompSize 0xEC04E
/* Ende Includefile f�r C-Programm */
