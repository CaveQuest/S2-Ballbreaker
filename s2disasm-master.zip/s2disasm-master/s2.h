comp_z80_size 0xF4A e f�r C-Programm */
#define word_728C_user 0x71C0
#define Obj5F_MapUnc_7240 0x7240
#define off_3A294 0x3A294
#define MapRUnc_Sonic 0x714E0
#define movewZ80CompSize 0xEC04E
/* Ende Includefile f�r C-Programm */
